import { DataService } from './../Shared/Services/data-service';
import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  @ViewChild('loginForm') form: any;

  defaultSubscription = 'Advanced';

  constructor(private dataService: DataService, private router: Router) { }
  ngOnInit() {

  }

  onSubmit(form: NgForm) {
    this.dataService.saveData(form.value);
    this.router.navigateByUrl('/home');
    console.log(form);

  }

  clear() {
    if (confirm('Do you want to reset the form?') == true) {
      this.form.reset();
    } else {
      console.log('No changes');
    }


  }

}
