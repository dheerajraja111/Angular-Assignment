import { BrowserModule } from '@angular/platform-browser';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ExtraOptions, RouterModule, Routes } from '@angular/router';
import { NgModule, Component } from '@angular/core';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: '**',
    redirectTo: 'login'
  }
];

const config: ExtraOptions = {
    useHash: false,
};

@NgModule({
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes, config)
  ],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
