export class Login {
    email: string;
    password: string;
    subscription: string;
}
