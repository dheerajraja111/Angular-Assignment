import { Login } from './../../models/login.model';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscriber } from 'rxjs/Subscriber';

export interface MyData {
    email: string;
    password: string;
}


@Injectable()
export class DataService {

    formData: any;

    constructor() {
    }

    public saveData(loginData) {
        this.formData = loginData;
        console.log(this.formData);
    }

    public getData() {
        return this.formData;
    }
}
