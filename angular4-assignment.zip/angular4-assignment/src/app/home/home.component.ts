import { DataService } from './../Shared/Services/data-service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  homeData: any;
  mailData: any;
  passwordData: any;
  subscriptionData: any;

  constructor(private dataService: DataService) {
    this.homeData = this.dataService.getData();
    this.mailData = this.homeData.email;
    this.passwordData = this.homeData.password;
    this.subscriptionData = this.homeData.subscriptions;
   }

  ngOnInit() {
  }



}
